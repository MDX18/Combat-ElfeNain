﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using CombatServeurSocketElfe.Classes;

namespace CombatServeurSocketElfe
{
    public partial class frmServeurSocketElfe : Form
    {
        Random m_r;
        Nain m_nain;
        Elfe m_elfe;
        TcpListener m_ServerListener;
        Socket m_client;
        Thread th_start;

        public frmServeurSocketElfe()
        {
            InitializeComponent();
            m_r = new Random();
            Reset();
            btnReset.Enabled = false;
            //Démarre un serveur de socket (TcpListener)
            m_ServerListener = new TcpListener(IPAddress.Parse("127.0.0.1"), 7777);
            m_ServerListener.Start();
            lstReception.Items.Add("Serveur démarré !");
            lstReception.Items.Add("PRESSER : << attendre un client >>");
            lstReception.Update();
            Control.CheckForIllegalCrossThreadCalls = false;
        }
        void Reset()
        {
            m_nain = new Nain(1, 0, 0);
            picNain.Image = m_nain.Avatar;
            AfficheStatNain();

            m_elfe = new Elfe(m_r.Next(10, 20), m_r.Next(2, 6), m_r.Next(2, 6));
            picElfe.Image = m_elfe.Avatar;
            AfficheStatElfe();
 
            lstReception.Items.Clear();
        }

        void AfficheStatNain()
        {
            lblVieNain.Text = m_nain.Vie.ToString();
            lblForceNain.Text = m_nain.Force.ToString();
            lblArmeNain.Text=m_nain.Arme.ToString();    
            this.Update(); // pour s'assurer de l'affichage via le thread
        }
        void AfficheStatElfe()
        {
            lblVieElfe.Text=m_elfe.Vie.ToString();
            lblForceElfe.Text= m_elfe.Force.ToString();
            lblSortElfe.Text=m_elfe.Sort.ToString();
            this.Update(); // pour s'assurer de l'affichage via le thread
        }
        private void btnReset_Click(object sender, EventArgs e)
        {

            Reset();
        }

        private void btnAttente_Click(object sender, EventArgs e)
        {
            ThreadStart combat = new ThreadStart(Combat);
            th_start = new Thread(combat);
            th_start.Start();
        }

        public void Combat() 
        {
            // déclarations de variables locales 
            int nbOctetReception;
            byte[] tByteReception = new byte[100];
            byte[] tByteEnvoie = new byte[100];
            string[] tRecup;
            string ReceptionClient = string.Empty;
            string ReponseServeur = string.Empty;

            try
            {
                while (m_nain.Vie>0 && m_elfe.Vie>0)
                {
                    //attend une connexion cliente socket
                    m_client = m_ServerListener.AcceptSocket();

                    lstReception.Items.Add("Client branché !");
                    lstReception.Update();
                    Thread.Sleep(500);

                    //reçoit les données cliente du nain
                    nbOctetReception = m_client.Receive(tByteReception);
                    ReceptionClient = Encoding.ASCII.GetString(tByteReception);

                    lstReception.Items.Add("du client: " + ReceptionClient);
                    lstReception.Update();
                    //split sur le ";" pour récupérer les données d'un nain
                    tRecup = ReceptionClient.Split(';');
                    lblVieNain.Text = tRecup[0];
                    m_nain.Vie = Convert.ToInt32(tRecup[0]);
                    lblForceNain.Text = tRecup[1];
                    m_nain.Force = Convert.ToInt32(tRecup[1]);
                    lblArmeNain.Text = tRecup[2];
                    m_nain.Arme = tRecup[2];

                    AfficheStatNain();

                    //exécute Frapper
                    MessageBox.Show("Serveur: Frapper l'elfe");
                    m_nain.Frapper(m_elfe);

                    //Affiche les stats de l'elfe
                    AfficheStatElfe();

                    //exécute LanceSort
                    MessageBox.Show("Serveur: Lancer un sort au nain");
                    m_elfe.LancerSort(m_nain);

                    //Affiche les données du nain et de l'elfe
                    AfficheStatNain();
                    AfficheStatElfe();

                    ReponseServeur = m_nain.Vie.ToString() + ";" + m_nain.Force.ToString() + ";" + m_nain.Arme.ToString() + ";" + m_elfe.Vie.ToString() + ";" + m_elfe.Force.ToString() +";"+ m_elfe.Sort.ToString()+ ";";

                    //Conversion de la réponse du serveur en byte[]
                    tByteEnvoie = Encoding.ASCII.GetBytes(ReponseServeur);

                    //Envoie les données au client
                    m_client.Send(tByteEnvoie);
                }
                // Vérifie le gagnant
                if (m_nain.Vie==0)
                {
                    MessageBox.Show("L'elfe est le gagnant!!!");
                }
                else
                {
                    MessageBox.Show("Le nain est le gagnant!!!");
                }

                btnReset.Enabled = true;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception serveur: " + ex.Message);
            }
        } 

        private void btnFermer_Click(object sender, EventArgs e)
        {
            // il faut avoir un objet elfe et un objet nain instanciés
            //m_elfe.Vie = 0;
            //m_nain.Vie = 0;
            try
            {
                m_elfe.Vie = 0;
                m_nain.Vie = 0;
                Thread.Sleep(1000);
                th_start.Abort();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception serveur: " + ex.Message);
            }
        }

        private void frmServeurSocketElfe_FormClosing(object sender, FormClosingEventArgs e)
        {
            btnFermer_Click(sender,e);
            try
            {
                // il faut avoir un objet TCPListener existant
                 m_ServerListener.Stop();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception serveur: " + ex.Message);
            }
        }
    }
}
